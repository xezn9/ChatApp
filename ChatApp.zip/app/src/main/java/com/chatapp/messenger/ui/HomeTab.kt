package com.chatapp.messenger.ui

import com.chatapp.messenger.ui.theme.AppFont

import androidx.compose.material.icons.filled.Star
import androidx.compose.animation.core.tween
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import com.chatapp.messenger.ActiveStory
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import com.chatapp.messenger.GroupItem
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chatapp.messenger.ChatItem
import com.chatapp.messenger.Profile
import com.chatapp.messenger.Repo
import com.chatapp.messenger.UserItem

/** يتذكر آخر واجهة واتجاه التبديل (1 = للأمام، -1 = للخلف) لحركة الدوّار بين المحادثات/المجموعات/الطلبات */
private class ModeDir(var cur: Int, var dir: Float = 1f)

/**
 * تبويب Home:
 * - بدون بحث: قائمة المحادثات (صورة + اسم الشخص + آخر رسالة)
 * - بالبحث (اسم أو يوزر): نتائج المستخدمين، ضغطة تفتح بروفايله وفيه زر مراسلة
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTab(
    onOpenChat: (UserItem) -> Unit, onOpenProfile: (UserItem) -> Unit, onRequestLogout: () -> Unit,
    onRequestDeleteChat: (uid: String, name: String, lastAt: Long) -> Unit = { _, _, _ -> },
    onOverlayChange: (Boolean) -> Unit = {},
    // 0 = المحادثات العادية، 1 = المجموعات، 2 = طلبات الرسائل (المبدّل نفسه يرسم من MainScreen فوق هذي الصفحة)
    homeMode: Int = 0,
    // فتح محادثة مجموعة
    onOpenGroup: (GroupItem) -> Unit = {},
    // فتح محادثة الدعم (معرّف صاحب المحادثة: أنا للمستخدم، أو المستخدم الي راسل للمطور)
    onOpenSupport: (String) -> Unit = {}
) {
    val myUid = remember { Repo.auth.currentUser?.uid ?: "" }
    val users by remember { Repo.usersFlow() }.collectAsState(initial = emptyList())
    val chats by remember(myUid) { Repo.chatsFlow(myUid) }.collectAsState(initial = emptyList())
    val pinned by remember(myUid) { Repo.pinnedFlow(myUid) }.collectAsState(initial = emptySet())
    // null = لسا ما وصلت قائمة المحذوفات: ما نعرض أي محادثة (حتى ما تبين المحذوفة/القديمة لحظة)
    val clearedState by remember(myUid) { Repo.clearedFlow(myUid) }.collectAsState(initial = null as Map<String, Long>?)
    var clearedTimeout by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(2500); clearedTimeout = true }
    val clearedReady = clearedState != null || clearedTimeout
    val cleared = clearedState ?: emptyMap()
    // معاينة بديلة إذا حذفت (من عندي) آخر رسالة بمحادثة
    val previewOverrides by remember(myUid) { Repo.previewOverridesFlow(myUid) }.collectAsState(initial = emptyMap())
    // لكل واجهة بحثها المستقل (حتى ما يتلخبط البحث أثناء حركة التبديل)
    var queryChats by remember { mutableStateOf("") }
    var queryGroups by remember { mutableStateOf("") }
    // قصص كل المستخدمين (مع قصتي أولاً)
    val stories by remember { Repo.activeStoriesFlow() }.collectAsState(initial = emptyList())
    var viewIndex by remember { mutableStateOf<Int?>(null) }
    var storySnapshot by remember { mutableStateOf<List<ActiveStory>>(emptyList()) }
    var lastIdx by remember { mutableStateOf(0) }
    LaunchedEffect(viewIndex != null) { onOverlayChange(viewIndex != null) }
    DisposableEffect(Unit) { onDispose { onOverlayChange(false) } }

    // المثبتين (الأشخاص المميزين) أولاً، حتى لو ما عندهم رسائل بعد
    val shownChats = remember(chats, pinned, cleared, clearedReady) {
        if (!clearedReady) return@remember emptyList<ChatItem>()
        // المحادثات المحذوفة من عندي تنخفي (لين توصل رسالة جديدة)
        // (وطلبات الرسائل ما تظهر هنا: لها واجهتها الخاصة لين أوافق عليها)
        val visible = chats.filter { !it.req && it.lastAt > (cleared[it.uid] ?: 0L) }
        val byUid = visible.associateBy { it.uid }
        val top = pinned.map { byUid[it] ?: ChatItem(it, "", 0L) }.sortedByDescending { it.lastAt }
        top + visible.filter { it.uid !in pinned }
    }

    // طلبات الرسائل: أول رسالة من شخص جديد وأنا مشغّل "طلبات الرسائل"، بانتظار موافقتي
    val requests = remember(chats, cleared, clearedReady) {
        if (!clearedReady) emptyList() else chats.filter { it.req && it.lastAt > (cleared[it.uid] ?: 0L) }
    }

    val groups by remember(myUid) { Repo.groupsFlow(myUid) }.collectAsState(initial = emptyList())

    // الدعم الفني: محادثتي مع "ChatApp" (إذا راسلت أو وصلني رد)، وللمطور صندوق دعم بكل المستخدمين
    val isDev = rememberIsDev()
    val myThread by remember(myUid) { Support.threadFlow(myUid) }.collectAsState(initial = null)
    val devThreads by remember(isDev) {
        if (isDev) Support.allThreadsFlow() else kotlinx.coroutines.flow.flowOf(emptyList<SupportThread>())
    }.collectAsState(initial = emptyList())
    val myShownThread = myThread?.takeIf { clearedReady && it.lastAt > 0 && it.lastAt > (cleared["support:$myUid"] ?: 0L) }
    val inbox = if (!clearedReady) emptyList() else devThreads.filter { it.uid != myUid && it.lastAt > (cleared["support:${it.uid}"] ?: 0L) }

    // اتجاه التبديل بين الواجهات (يزيد = للأمام): نحسبه أثناء التركيب حتى تعرف الواجهتان جهة حركتهما
    val modeDir = remember { ModeDir(homeMode) }
    if (modeDir.cur != homeMode) {
        modeDir.dir = if (homeMode > modeDir.cur) 1f else -1f
        modeDir.cur = homeMode
    }

    Box(Modifier.fillMaxSize()) {
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    AnimatedContent(
                        targetState = homeMode,
                        transitionSpec = {
                            (slideInVertically(spring(0.85f, 420f)) { it / 2 } + fadeIn(tween(200))) togetherWith
                                (slideOutVertically(tween(160)) { -it / 2 } + fadeOut(tween(120)))
                        },
                        label = "homeTitle"
                    ) { m -> Text(when (m) { 1 -> "المجموعات"; 2 -> "طلبات الرسائل"; else -> "المحادثات" }) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                actions = { TextButton(onClick = onRequestLogout) { Text("تسجيل الخروج") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            // مكان المبدّل (يرسم من MainScreen): 68dp من فوق + ارتفاعه 44dp
            Spacer(Modifier.height(56.dp))
            // حركة التبديل: الواجهتان تدوران بشكل ثلاثي الأبعاد مثل دوّار (Carousel):
            // الي يطلع ينزلق للجنب ويدور ويصغر ويخفت، والي يدخل يجي من الجهة المقابلة بنبضة نابضية
            val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
            AnimatedContent(
                targetState = homeMode,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = {
                    (fadeIn(tween(240, delayMillis = 50)) togetherWith fadeOut(tween(150)))
                        .using(SizeTransform(clip = false))
                },
                label = "homeMode"
            ) { mode ->
                // الواجهة الي تطلع تنزلق لجهة، والي تدخل تجي من الجهة المقابلة (حسب اتجاه التبديل واتجاه الواجهة)
                val entering = mode == homeMode
                val side = (if (entering) -modeDir.dir else modeDir.dir) * (if (rtl) 1f else -1f)
                val p by transition.animateFloat(
                    transitionSpec = { spring(dampingRatio = 0.78f, stiffness = 240f) },
                    label = "homeFlip"
                ) { st -> if (st == EnterExitState.Visible) 0f else side }
                val query = if (mode == 1) queryGroups else queryChats
                val q = query.trim().removePrefix("@").lowercase()
                val shownGroups = if (q.isEmpty()) groups else groups.filter {
                    it.name.lowercase().contains(q) || it.handle.lowercase().contains(q)
                }
                val results = if (q.isEmpty()) emptyList() else users.filter {
                    it.uid != myUid && (it.name.lowercase().contains(q) || it.username.lowercase().contains(q))
                }
                Column(
                    Modifier.fillMaxSize().graphicsLayer {
                        val a = kotlin.math.abs(p)
                        translationX = p * size.width * 0.42f
                        rotationY = -p * 36f
                        cameraDistance = 14f * density
                        val sc = 1f - 0.12f * a
                        scaleX = sc
                        scaleY = sc
                    }
                ) {
            if (mode != 2) SearchField(
                query,
                if (mode == 1) "ابحث عن مجموعة" else "ابحث بالاسم أو اليوزر"
            ) { if (mode == 1) queryGroups = it else queryChats = it }
            if (q.isEmpty() && mode == 0) {
                StoriesRow(stories, myUid) { i ->
                    storySnapshot = stories
                    viewIndex = i
                }
            }

            when {
                // واجهة طلبات الرسائل: أول رسائل الأشخاص الجدد (ضغطة تفتح الطلب وفيه قبول/حذف)
                mode == 2 -> if (requests.isEmpty()) {
                    CenterText("ما عندك طلبات رسائل.\nإذا شغّلت \"طلبات الرسائل\" من الإعدادات > الخصوصية، رسائل الأشخاص الجدد تجيك هنا.")
                } else {
                    LazyColumn(contentPadding = PaddingValues(bottom = 130.dp)) {
                        item(key = "requestsHint") {
                            Text(
                                "هذي رسائل من أشخاص ما راسلتهم قبل. ما يشوفون إنك قريت الرسالة، وما يگدرون يرسلون غيرها لين توافق.",
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                            )
                        }
                        items(requests, key = { it.uid }) { c ->
                            val u = users.firstOrNull { it.uid == c.uid }
                            val toItem = { p: Profile ->
                                UserItem(c.uid, p.name.ifBlank { u?.name ?: "" }, u?.email ?: "", p.username.ifBlank { u?.username ?: "" })
                            }
                            UserRow(
                                uid = c.uid,
                                fallbackName = u?.name ?: "",
                                secondary = { c.lastText },
                                unread = c.unread,
                                onLongClick = { p ->
                                    onRequestDeleteChat(c.uid, p.name.ifBlank { u?.name ?: "" }.ifBlank { "مستخدم" }, c.lastAt)
                                },
                                onClick = { p -> onOpenChat(toItem(p)) },
                                onAvatarClick = { p -> onOpenProfile(toItem(p)) }
                            )
                        }
                    }
                }
                // واجهة المجموعات: مجموعاتي الحقيقية (من قاعدة البيانات)
                mode == 1 -> if (shownGroups.isEmpty()) {
                    CenterText(
                        if (q.isEmpty()) "ما عندك مجموعات بعد.\nاضغط زر إنشاء مجموعة حتى تبدأ أول مجموعة."
                        else "ما لقيت مجموعة بهذا الاسم"
                    )
                } else {
                    LazyColumn(contentPadding = PaddingValues(bottom = 130.dp)) {
                        items(shownGroups, key = { it.id }) { g ->
                            GroupRow(g, onClick = { onOpenGroup(g) })
                        }
                    }
                }
                q.isNotEmpty() -> {
                    if (results.isEmpty()) {
                        CenterText("ما لقيت أحد بهذا الاسم أو اليوزر")
                    } else {
                        LazyColumn(contentPadding = PaddingValues(bottom = 130.dp)) {
                            items(results, key = { it.uid }) { u ->
                                UserRow(
                                    uid = u.uid,
                                    fallbackName = u.name,
                                    secondary = { p -> "@" + p.username.ifBlank { u.username } },
                                    onClick = { onOpenProfile(u) },
                                    onAvatarClick = { onOpenProfile(u) }
                                )
                            }
                        }
                    }
                }
                !clearedReady -> Box(Modifier.fillMaxSize())
                shownChats.isEmpty() && myShownThread == null && inbox.isEmpty() -> CenterText("ما عندك محادثات بعد.\nابحث عن شخص بالاسم أو اليوزر حتى تبدأ محادثة.")
                else -> {
                    LazyColumn(
                        // مسافة بالأسفل حتى ما يختفي آخر عنصر خلف الشريط الزجاجي
                        contentPadding = PaddingValues(bottom = 130.dp)
                    ) {
                        if (myShownThread != null) {
                            item(key = "supportMine") { SupportChatRow(myShownThread, onLongClick = { onRequestDeleteChat("support:$myUid", "ChatApp", myShownThread.lastAt) }) { onOpenSupport(myUid) } }
                        }
                        items(inbox, key = { "support_" + it.uid }) { th ->
                            SupportInboxRow(th, onLongClick = { onRequestDeleteChat("support:${th.uid}", th.name.ifBlank { th.username }.ifBlank { "مستخدم" }, th.lastAt) }) { onOpenSupport(th.uid) }
                        }
                        items(shownChats, key = { it.uid }) { c ->
                            val u = users.firstOrNull { it.uid == c.uid }
                            val toItem = { p: Profile ->
                                UserItem(
                                    c.uid,
                                    p.name.ifBlank { u?.name ?: "" },
                                    u?.email ?: "",
                                    p.username.ifBlank { u?.username ?: "" }
                                )
                            }
                            UserRow(
                                uid = c.uid,
                                fallbackName = u?.name ?: "",
                                secondary = {
                                    val o = previewOverrides[c.uid]
                                    // تنطبق فقط إذا آخر نص ما زال نفس الي حذفته ولا وصلت رسالة جديدة بعده
                                    if (o != null && c.lastText == o.forText && c.lastAt <= o.at) o.text else c.lastText
                                },
                                pinned = c.uid in pinned,
                                unread = c.unread,
                                showPresence = true,
                                onLongClick = { p ->
                                    onRequestDeleteChat(
                                        c.uid,
                                        p.name.ifBlank { u?.name ?: "" }.ifBlank { "مستخدم" },
                                        c.lastAt
                                    )
                                },
                                onClick = { p -> onOpenChat(toItem(p)) },
                                onAvatarClick = { p -> onOpenProfile(toItem(p)) }
                            )
                        }
                    }
                }
            }
                }
            }
        }
    }

    // عارض القصص بملء الشاشة (يتنقل للقصة التالية تلقائياً)
    val vi = viewIndex
    if (vi != null) lastIdx = vi
    AnimatedVisibility(
        visible = vi != null,
        enter = fadeIn(tween(180)) + scaleIn(spring(0.85f, 400f), initialScale = 0.88f),
        exit = fadeOut(tween(160)) + scaleOut(tween(180), targetScale = 0.92f)
    ) {
        storySnapshot.getOrNull(lastIdx)?.let { a ->
            val st = a.profile.story
            if (st != null) {
                key(a.uid) {
                    StoryViewerScreen(
                        story = st,
                        owner = a.profile,
                        mine = a.uid == myUid,
                        showMenu = false,
                        onDismiss = { viewIndex = null },
                        ownerUid = a.uid,
                        onOpenViewer = { u -> viewIndex = null; onOpenProfile(u) },
                        // ضغطة على صورة/اسم صاحب القصة تفتح ملفه الشخصي
                        onOpenProfile = {
                            viewIndex = null
                            onOpenProfile(UserItem(a.uid, a.profile.name, "", a.profile.username))
                        },
                        onFinished = {
                            val n = lastIdx + 1
                            viewIndex = if (n < storySnapshot.size) n else null
                        }
                    )
                }
            }
        }
    }
    }
}

@Composable
private fun CenterText(text: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
    }
}

/** مربع بحث بستايل iOS */
@Composable
private fun SearchField(value: String, hint: String = "ابحث بالاسم أو اليوزر", onChange: (String) -> Unit) {
    val fg = MaterialTheme.colorScheme.onBackground
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(shape).background(fg.copy(alpha = 0.08f))
            .border(0.8.dp, fg.copy(alpha = 0.12f), shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = fg.copy(alpha = 0.6f), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(hint, color = fg.copy(alpha = 0.5f), fontSize = 16.sp)
            }
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(fontFamily = AppFont, color = fg, fontSize = 16.sp),
                cursorBrush = SolidColor(AccentBlue),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (value.isNotEmpty()) {
            Icon(
                Icons.Filled.Close, null, tint = fg.copy(alpha = 0.6f),
                modifier = Modifier.size(20.dp).clickable { onChange("") }
            )
        }
    }
}

/** صف مستخدم: صورة الملف الشخصي + الاسم + سطر ثانوي (آخر رسالة أو @اليوزر) */
@Composable
private fun UserRow(
    uid: String,
    fallbackName: String,
    secondary: (Profile) -> String,
    onClick: (Profile) -> Unit,
    onAvatarClick: (Profile) -> Unit,
    pinned: Boolean = false,
    unread: Int = 0,
    showPresence: Boolean = false,
    onLongClick: ((Profile) -> Unit)? = null
) {
    val haptic = LocalHapticFeedback.current
    val prof by remember(uid) { Repo.basicProfileFlow(uid) }.collectAsState(initial = Profile())
    val avatar = rememberB64Image(prof.avatar)
    val shown = prof.name.ifBlank { fallbackName }.ifBlank { "مستخدم" }
    // نقطة "متصل" الخضراء (فقط لصفوف المحادثات، حتى ما نفتح مستمع لكل نتيجة بحث)
    val online = showPresence && rememberPresenceStatus(uid).online

    val rowMod = if (onLongClick != null) {
        // ضغطة = فتح المحادثة، ضغطة مطولة = حذف المحادثة
        Modifier.fillMaxWidth().pointerInput(uid, prof) {
            detectTapGestures(
                onTap = { onClick(prof) },
                onLongPress = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick(prof)
                }
            )
        }
    } else Modifier.fillMaxWidth().clickable { onClick(prof) }
    Row(
        rowMod.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp)) {
            Box(
                Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFF2B2F36)).clickable { onAvatarClick(prof) },
                contentAlignment = Alignment.Center
            ) {
                if (avatar != null) {
                    Image(avatar, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Icon(Icons.Filled.Person, null, tint = Color(0xFF8A8F98), modifier = Modifier.size(28.dp))
                }
            }
            OnlineDot(online)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    shown, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                )
                BadgeAfterName(prof, 18.dp)
                if (pinned) {
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Filled.Star, null, tint = Color(0xFFFFC107), modifier = Modifier.size(15.dp))
                }
            }
            Text(
                secondary(prof), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (unread > 0) FontWeight.SemiBold else FontWeight.Normal,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = if (unread > 0) 0.9f else 0.6f)
            )
        }
        // شارة عدد الرسائل الجديدة (مثل تيك توك)
        AnimatedVisibility(
            visible = unread > 0,
            enter = scaleIn(spring(0.45f, 500f)) + fadeIn(),
            exit = scaleOut() + fadeOut()
        ) {
            Box(
                Modifier.padding(start = 8.dp).defaultMinSize(minWidth = 24.dp, minHeight = 24.dp)
                    .clip(CircleShape).background(Color(0xFFFF3B5C)).padding(horizontal = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (unread > 99) "99+" else unread.toString(),
                    color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/** صف مجموعة: صورة المجموعة + الاسم + آخر رسالة (أو @المعرّف وعدد الأعضاء) */
@Composable
private fun GroupRow(g: GroupItem, onClick: () -> Unit) {
    val last by remember(g.id) { Repo.groupLastMessageFlow(g.id) }.collectAsState(initial = null)
    val members = if (g.memberCount == 1) "عضو واحد" else "${g.memberCount} أعضاء"
    val secondary = last?.text?.takeIf { it.isNotBlank() } ?: buildString {
        if (g.handle.isNotBlank()) append("@").append(g.handle).append(" · ")
        append(members)
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GroupAvatar(g.avatar, 52.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                g.name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                secondary, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }
    }
}
